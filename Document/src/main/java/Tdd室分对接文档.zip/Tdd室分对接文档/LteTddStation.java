package com.example.bs.package1;

import java.io.Serializable;

/**
 * 基站为单位接收app上传的信息
 * 
 * @author weichengz
 * @date 2019年1月25日 下午11:38:43
 */
public class LteTddStation implements Serializable {

	private static final long serialVersionUID = 1L;

	private String id;
	private String enodeBID;// 基站号
	private String baseStationName;// 基站名

	private String testDate;// 测试时间

	private String csfbFunctionTestPass;// CSFB功能测试 是否通过
	private String volteFunctionTestPass;// VoLTE功能测试 是否通过

	// common
	private Integer projId;

	/**
	 * 以下为上传图片的名字
	 */
	private String allViewPicMulti;// 建筑物全景照（从地面仰视）
	private String stationEntrancePicMulti;// 站点入口图

}
