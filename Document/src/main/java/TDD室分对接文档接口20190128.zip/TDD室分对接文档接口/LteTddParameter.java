﻿package com.example.bs.package1;

import java.io.Serializable;
import java.util.Date;

/**
 * lte tdd app对接参数信息 以小区为单位
 * 
 * @author weichengz
 * @date 2018年12月31日 下午10:31:14
 */
public class LteTddParameter implements Serializable {

	private static final long serialVersionUID = 1L;

	private String id;
	private String enodeBID;// 基站号
	private String baseStationName;// 基站名
	private String cellId;// 小区号
	private String cellName;// 小区名称
	private String testDate;// 测试时间

   private String  userId;//用户的id

	private String ftpDownPass;// FTP下载是否通过
	private String ftpUpPass;// FTP上传是否通过

	/** 小区工程参数 **/
	private String eci;
	private String earfcn;
	private String pci;
	private String tac;

	// CSFB呼叫成功率
	private String csfCallAttempt;//尝试次数
	private String csfbCallSucc;//成功次数
	private String csfbCallFailure;//失败次数   下同
	// Volte呼叫成功率
	private String volteCallAttempt;
	private String volteCallSucc;
	private String volteCallFailure;
	// Volte呼叫掉线率
	private String volteDownAttempt;
	private String volteDownSucc;
	private String volteDownFailure;

	// FTP下行吞吐率
	// 覆盖率
	private String ftpDownCover;// 遍历性测试性能指标
	private String ftpDownCoverRandom;// 任意点
	// 下行吞吐率
	private String ftpDownThroughput;// 遍历性测试性能指标
	private String ftpDownThroughputRandom;// 任意点

	// FTP上行吞吐率
	// 覆盖率
	private String ftpUpCover;// 遍历性测试性能指标
	private String ftpUpCoverRandom;// 任意点
	// 上行吞吐率
	private String ftpUpThroughput;// 遍历性测试性能指标
	private String ftpUpThroughputRandom;// 任意点

	// common
	private Integer projId;
	

	// 底层
	private String lowNum;//楼层
	private String lowRsrp;//RSRP
	private String lowSinr;//SINR
	private String lowCallSuccPercent;//呼叫成功率   下同
	// 中层
	private String middleNum;
	private String middleRsrp;
	private String middleSinr;
	private String middleCallSuccPercent;
	// 高层
	private String highNum;
	private String highRsrp;
	private String highSinr;
	private String highCallSuccPercent;
	// 地下室
	private String baseNum;
	private String baseRsrp;
	private String baseSinr;
	private String baseCallSuccPercent;
	// 电梯
	private String elevatorNum;
	private String elevatorRsrp;
	private String elevatorSinr;
	private String elevatorCallSuccPercent;

	private String volteSwitch;// VoLTE开关

	
	
	
	/**
	 * 一下图  对应的是上传html图片属性中的name属性的值
	 */
	// 性能验收覆盖效果图
	private String rsrpPicMulti; // RSRP覆盖图
	private String sinrPicMulti; // SINR
	private String downRatePicMulti;// 下载速率
	private String upRatePicMulti;// 上传速率

	// 楼层覆盖效果图
	private String flowCoverRsrpPicMulti; // RSRP覆盖图
	private String flowCoverSinrPicMulti; // SINR覆盖图
	private String flowCoverpCIPicMulti;// pci覆盖图

	// 测试层图片 这个是个[数组] 
	 testFlowImage;

	


              private String token;//安全验证字符串





}

注意：
  项目projId、基站号enodeBID、小区号cellId、测试时间testDate、创建者userId不能为空
  其他的根据情况可多次上传，上传的原则就是:不存在则新增，存在就覆盖。
  
