package com.example.bs.package1;

import java.io.Serializable;

/**
 * 基站为单位接收app上传的信息
 * 
 * @author weichengz
 * @date 2019年1月25日 下午11:38:43
 */
public class LteTddStation implements Serializable {

	private static final long serialVersionUID = 1L;

	private String id;
	private String enodeBID;// 基站号
	private String baseStationName;// 基站名

	private Interger userId;//用户的id

	private String testDate;// 测试时间

	private String csfbFunctionTestPass;// CSFB功能测试 是否通过
	private String volteFunctionTestPass;// VoLTE功能测试 是否通过
    

	private String token;//安全验证字符串


	// common
	private Integer projId;

	/**
	 * 以下为上传图片的名字
	 */
	private String allViewPicMulti;// 建筑物全景照（从地面仰视）
	private String stationEntrancePicMulti;// 站点入口图

}

注意：
  项目projId、基站号enodeBID、测试时间testDate、创建者userId不能为空  token不能为空，
   其他的根据情况可多次上传，上传的原则就是:不存在则新增，存在就覆盖。
